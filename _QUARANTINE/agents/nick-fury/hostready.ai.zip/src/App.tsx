/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  GoogleAuthProvider, 
  signInWithPopup, 
  onAuthStateChanged, 
  User, 
  signOut 
} from 'firebase/auth';
import { 
  collection, 
  addDoc, 
  query, 
  where, 
  onSnapshot, 
  updateDoc, 
  doc, 
  deleteDoc, 
  serverTimestamp,
  getDocFromServer
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { GoogleGenAI } from "@google/genai";
import { 
  Home, 
  CheckCircle2, 
  FileText, 
  ShieldCheck, 
  Plus, 
  Search, 
  Loader2, 
  AlertCircle, 
  LogOut, 
  ChevronRight,
  Upload,
  Trash2,
  Info,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// --- Utilities ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

async function withRetry<T>(
  operation: () => Promise<T>,
  maxRetries = 3,
  delayMs = 1000
): Promise<T> {
  let lastError: unknown;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      const errorMessage = error instanceof Error ? error.message : String(error);
      const isTransient = 
        errorMessage.includes('unavailable') || 
        errorMessage.includes('deadline-exceeded') || 
        errorMessage.includes('network') ||
        errorMessage.includes('offline');
      
      if (!isTransient) {
        throw error; // Don't retry non-transient errors
      }
      
      console.warn(`Transient network error encountered, retrying... (${i + 1}/${maxRetries})`);
      await new Promise(resolve => setTimeout(resolve, delayMs * Math.pow(2, i)));
    }
  }
  throw lastError;
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errorMessage = error instanceof Error ? error.message : String(error);
  const isPermissionError = errorMessage.includes('Missing or insufficient permissions');

  if (isPermissionError) {
    const errInfo: FirestoreErrorInfo = {
      error: errorMessage,
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
        emailVerified: auth.currentUser?.emailVerified,
        isAnonymous: auth.currentUser?.isAnonymous,
        tenantId: auth.currentUser?.tenantId,
        providerInfo: auth.currentUser?.providerData.map(provider => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL
        })) || []
      },
      operationType,
      path
    };
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  }
  
  // For non-permission errors, provide a user-friendly message
  let userFriendlyMessage = "An unexpected error occurred while communicating with the database.";
  if (errorMessage.includes('offline') || errorMessage.includes('network') || errorMessage.includes('unavailable')) {
    userFriendlyMessage = "Network error: Please check your internet connection and try again.";
  } else if (errorMessage.includes('quota')) {
    userFriendlyMessage = "Service quota exceeded: Please try again later.";
  } else if (errorMessage.includes('not-found')) {
    userFriendlyMessage = "The requested data could not be found.";
  }
  
  console.error(`Firestore ${operationType} Error on ${path}:`, error);
  alert(userFriendlyMessage);
}

// --- Error Boundary ---
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean; error: any }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      let message = "Something went wrong.";
      try {
        const parsed = JSON.parse(this.state.error.message);
        if (parsed.error) message = `Firestore Error: ${parsed.error}`;
      } catch (e) {
        message = this.state.error.message || message;
      }
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-red-50">
          <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-red-100 text-center space-y-4">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto" />
            <h2 className="text-xl font-bold text-zinc-900">Application Error</h2>
            <p className="text-sm text-zinc-500">{message}</p>
            <Button onClick={() => window.location.reload()} className="w-full">Reload App</Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- Types ---
interface ChecklistItem {
  id: string;
  task: string;
  completed: boolean;
  category: 'Legal' | 'Safety' | 'HOA' | 'Logistics';
  notes?: string;
}

interface Property {
  id: string;
  ownerId: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  propertyType: string;
  status: 'Researching' | 'Gathering Docs' | 'Compliance Check' | 'Ready';
  checklist: ChecklistItem[];
  jurisdictionalRules?: string;
  createdAt: any;
}

interface DocumentRecord {
  id: string;
  propertyId: string;
  ownerId: string;
  type: 'HOA Agreement' | 'Insurance' | 'Permit Application' | 'Other';
  fileName: string;
  analysis?: string;
  complianceStatus: 'Pending' | 'Compliant' | 'Non-Compliant' | 'Needs Review';
  createdAt: any;
}

// --- Components ---

const Logo = ({ className }: { className?: string }) => (
  <div className={cn("relative", className)}>
    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-xl">
      <defs>
        <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0d7a82" />
          <stop offset="100%" stopColor="#14b8a6" />
        </linearGradient>
      </defs>
      {/* Shield Background */}
      <path 
        d="M50 5 L15 20 V50 C15 75 50 95 50 95 C50 95 85 75 85 50 V20 L50 5Z" 
        fill="url(#shieldGrad)" 
      />
      {/* House Shape */}
      <path 
        d="M50 25 L28 45 V75 H42 V60 H58 V75 H72 V45 L50 25Z" 
        fill="white" 
        fillOpacity="0.9"
      />
      {/* Checkmark Overlap */}
      <path 
        d="M40 55 L50 65 L75 35" 
        stroke="#0d7a82" 
        strokeWidth="8" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        className="drop-shadow-sm"
      />
    </svg>
  </div>
);

const Button = ({ className, variant = 'primary', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'outline' | 'danger' }) => {
  const variants = {
    primary: 'bg-brand-primary text-white hover:bg-brand-primary/90 shadow-sm shadow-brand-primary/10',
    secondary: 'bg-zinc-100 text-brand-dark hover:bg-zinc-200',
    outline: 'border border-zinc-200 text-zinc-600 hover:bg-zinc-50',
    danger: 'bg-red-50 text-red-600 hover:bg-red-100 border border-red-100',
  };
  return (
    <button 
      className={cn('px-4 py-2 rounded-lg font-medium transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2', variants[variant], className)} 
      {...props} 
    />
  );
};

const Card = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={cn('bg-white border border-zinc-100 rounded-2xl shadow-sm overflow-hidden', className)}>
    {children}
  </div>
);

const Badge = ({ children, variant = 'neutral' }: { children: React.ReactNode; variant?: 'neutral' | 'success' | 'warning' | 'error' | 'info' }) => {
  const variants = {
    neutral: 'bg-zinc-100 text-zinc-600',
    success: 'bg-emerald-50 text-emerald-700',
    warning: 'bg-amber-50 text-amber-700',
    error: 'bg-red-50 text-red-700',
    info: 'bg-blue-50 text-blue-700',
  };
  return (
    <span className={cn('px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider', variants[variant])}>
      {children}
    </span>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [properties, setProperties] = useState<Property[]>([]);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const [isAddingProperty, setIsAddingProperty] = useState(false);
  const [isLawsModalOpen, setIsLawsModalOpen] = useState(false);
  const [hoaUploadItemId, setHoaUploadItemId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');
  const [propType, setPropType] = useState('Single Family');

  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!user) return;
    const path = 'properties';
    const q = query(collection(db, path), where('ownerId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const props = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Property));
      setProperties(props);
      if (selectedProperty) {
        const updated = props.find(p => p.id === selectedProperty.id);
        if (updated) setSelectedProperty(updated);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
    return unsubscribe;
  }, [user]);

  useEffect(() => {
    if (!selectedProperty || !user) return;
    const path = 'documents';
    const q = query(collection(db, path), where('propertyId', '==', selectedProperty.id), where('ownerId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setDocuments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as DocumentRecord)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
    return unsubscribe;
  }, [selectedProperty, user]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error(err);
      setError('Failed to login. Please try again.');
    }
  };

  const handleLogout = () => signOut(auth);

  const createProperty = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setAiLoading(true);
    setError(null);

    try {
      // 1. Initial Research with Gemini
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `I am planning to list a short-term rental property at ${address}, ${city}, ${state} ${zip}. 
      Please research the current short-term rental (STR) regulations, zoning laws, and permit requirements for this specific jurisdiction. 
      Also, try to find the HOA rules for this specific address if applicable.
      Provide a concise summary of the rules and a recommended checklist of 5-7 items I need to complete to be compliant. 
      Format the checklist as a JSON array of objects with 'task', 'category' (Legal, Safety, HOA, Logistics), and 'completed' (boolean).
      If you are able to access the HOA info and verify it allows STRs, set 'completed' to true for the HOA task. Otherwise, set it to false.`;

      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      const responseText = result.text || '';
      
      // Attempt to extract JSON checklist
      let checklist: ChecklistItem[] = [];
      try {
        const jsonMatch = responseText.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          checklist = parsed.map((item: any, idx: number) => ({
            id: `cl-${Date.now()}-${idx}`,
            task: item.task,
            category: item.category || 'Legal',
            completed: false
          }));
        }
      } catch (e) {
        console.warn("Failed to parse AI checklist", e);
        checklist = [
          { id: '1', task: 'Apply for STR Permit', category: 'Legal', completed: false },
          { id: '2', task: 'Install Smoke Detectors', category: 'Safety', completed: false },
          { id: '3', task: 'Check HOA Rules', category: 'HOA', completed: false },
        ];
      }

      const newProp = {
        ownerId: user.uid,
        address,
        city,
        state,
        zipCode: zip,
        propertyType: propType,
        status: 'Researching',
        checklist,
        jurisdictionalRules: responseText,
        createdAt: serverTimestamp(),
      };

      const docRef = await withRetry(() => addDoc(collection(db, 'properties'), newProp));
      setIsAddingProperty(false);
      setAddress(''); setCity(''); setState(''); setZip('');
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.CREATE, 'properties');
    } finally {
      setAiLoading(false);
    }
  };

  const runResearch = async (property: Property) => {
    if (!user) return;
    setAiLoading(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `I am planning to list a short-term rental property at ${property.address}, ${property.city}, ${property.state} ${property.zipCode}. 
      Please research the current short-term rental (STR) regulations, zoning laws, and permit requirements for this specific jurisdiction. 
      Also, try to find the HOA rules for this specific address if applicable.
      Provide a concise summary of the rules and a recommended checklist of 5-7 items I need to complete to be compliant. 
      Format the checklist as a JSON array of objects with 'task', 'category' (Legal, Safety, HOA, Logistics), and 'completed' (boolean).
      If you are able to access the HOA info and verify it allows STRs, set 'completed' to true for the HOA task. Otherwise, set it to false.`;

      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: { tools: [{ googleSearch: {} }] },
      });

      const responseText = result.text || '';
      let checklist: ChecklistItem[] = property.checklist;
      try {
        const jsonMatch = responseText.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          const newItems = parsed.map((item: any, idx: number) => ({
            id: `cl-${Date.now()}-${idx}`,
            task: item.task,
            category: item.category || 'Legal',
            completed: false
          }));
          // Merge or replace? Let's replace for fresh research
          checklist = newItems;
        }
      } catch (e) {
        console.warn("Failed to parse AI checklist", e);
      }

      await withRetry(() => updateDoc(doc(db, 'properties', property.id), {
        jurisdictionalRules: responseText,
        checklist,
        status: 'Researching'
      }));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `properties/${property.id}`);
    } finally {
      setAiLoading(false);
    }
  };

  const toggleChecklistItem = async (property: Property, itemId: string) => {
    const item = property.checklist.find(i => i.id === itemId);
    if (item && item.category === 'HOA' && !item.completed) {
      setHoaUploadItemId(itemId);
      return;
    }
    try {
      const updatedChecklist = property.checklist.map(item => 
        item.id === itemId ? { ...item, completed: !item.completed } : item
      );
      await withRetry(() => updateDoc(doc(db, 'properties', property.id), { checklist: updatedChecklist }));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `properties/${property.id}`);
    }
  };

  const deleteProperty = async (id: string) => {
    if (!confirm('Are you sure you want to delete this property?')) return;
    try {
      await withRetry(() => deleteDoc(doc(db, 'properties', id)));
      if (selectedProperty?.id === id) setSelectedProperty(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `properties/${id}`);
    }
  };

  const analyzeDocument = async (file: File, type: DocumentRecord['type'], checklistItemId?: string) => {
    if (!user || !selectedProperty) return;
    setAiLoading(true);
    setError(null);

    try {
      // In a real app, we'd upload to Storage. Here we'll read as text/base64 for AI analysis.
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const prompt = `Review this ${type} for the property at ${selectedProperty.address}. 
        Identify any clauses that specifically allow or restrict short-term rentals (STRs), AirBnB, or subletting. 
        Determine if the document is 'Compliant', 'Non-Compliant', or 'Needs Review'. 
        Provide a concise summary of the findings.`;

        const result = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: {
            parts: [
              { inlineData: { data: base64Data, mimeType: file.type } },
              { text: prompt }
            ]
          }
        });

        const analysis = result.text || 'No analysis generated.';
        const status = analysis.toLowerCase().includes('compliant') && !analysis.toLowerCase().includes('non-compliant') 
          ? 'Compliant' 
          : analysis.toLowerCase().includes('non-compliant') ? 'Non-Compliant' : 'Needs Review';

        await withRetry(() => addDoc(collection(db, 'documents'), {
          propertyId: selectedProperty.id,
          ownerId: user.uid,
          type,
          fileName: file.name,
          analysis,
          complianceStatus: status,
          createdAt: serverTimestamp(),
        }));

        if (checklistItemId && status === 'Compliant') {
          const updatedChecklist = selectedProperty.checklist.map(item => 
            item.id === checklistItemId ? { ...item, completed: true } : item
          );
          await withRetry(() => updateDoc(doc(db, 'properties', selectedProperty.id), { checklist: updatedChecklist }));
        }

        setAiLoading(false);
      };
    } catch (err) {
      console.error(err);
      handleFirestoreError(err, OperationType.CREATE, 'documents');
      setAiLoading(false);
    }
  };

  const filteredProperties = useMemo(() => {
    if (!searchQuery.trim()) return properties;
    const query = searchQuery.toLowerCase();
    return properties.filter(p => 
      p.address.toLowerCase().includes(query) || 
      p.city.toLowerCase().includes(query) || 
      p.state.toLowerCase().includes(query)
    );
  }, [properties, searchQuery]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50">
        <Loader2 className="w-8 h-8 animate-spin text-zinc-400" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-brand-light flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md text-center space-y-8">
          <div className="space-y-4">
            <Logo className="w-20 h-20 mx-auto mb-6" />
            <div className="space-y-1">
              <h1 className="text-4xl font-bold tracking-tight text-brand-dark">hostready.ai</h1>
              <p className="text-zinc-500 font-medium">Hosting & Compliance Made Easy</p>
            </div>
          </div>
          <Card className="p-8 space-y-6">
            <div className="space-y-4 text-left">
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-brand-primary/10 flex items-center justify-center shrink-0">
                  <Search className="w-4 h-4 text-brand-primary" />
                </div>
                <div>
                  <p className="font-medium text-brand-dark">Jurisdictional Research</p>
                  <p className="text-sm text-zinc-500">AI scans local laws to find permit requirements and zoning rules.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-brand-primary/10 flex items-center justify-center shrink-0">
                  <FileText className="w-4 h-4 text-brand-primary" />
                </div>
                <div>
                  <p className="font-medium text-brand-dark">Document Review</p>
                  <p className="text-sm text-zinc-500">Upload HOA agreements or insurance policies for instant AI analysis.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-brand-primary/10 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4 text-brand-primary" />
                </div>
                <div>
                  <p className="font-medium text-brand-dark">Compliance Checklist</p>
                  <p className="text-sm text-zinc-500">Track your progress with a custom generated checklist for your area.</p>
                </div>
              </div>
            </div>
            <Button onClick={handleLogin} className="w-full py-4 text-lg font-bold">
              Get Started with Google
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-zinc-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-zinc-100 sticky top-0 z-10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setSelectedProperty(null)}>
            <Logo className="w-8 h-8" />
            <span className="text-xl font-bold tracking-tight text-brand-dark">hostready.ai</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-medium text-brand-dark">{user.displayName}</p>
              <p className="text-xs text-zinc-500">{user.email}</p>
            </div>
            <button onClick={handleLogout} className="p-2 hover:bg-zinc-100 rounded-full transition-colors text-zinc-400 hover:text-zinc-600">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar / Property List */}
        <div className="lg:col-span-4 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-zinc-900">Your Properties</h2>
            <Button variant="secondary" onClick={() => setIsAddingProperty(true)} className="px-3 py-1.5 text-sm">
              <Plus className="w-4 h-4" /> Add
            </Button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text"
              placeholder="Search properties..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-zinc-200 text-sm focus:ring-2 focus:ring-brand-primary/10 outline-none bg-white shadow-sm"
            />
          </div>

          <div className="space-y-3">
            {properties.length === 0 && !isAddingProperty && !searchQuery && (
              <div className="text-center py-12 border-2 border-dashed border-zinc-200 rounded-2xl">
                <Home className="w-8 h-8 text-zinc-300 mx-auto mb-2" />
                <p className="text-sm text-zinc-500">No properties added yet.</p>
              </div>
            )}
            
            {properties.length > 0 && filteredProperties.length === 0 && (
              <div className="text-center py-12 border-2 border-dashed border-zinc-200 rounded-2xl">
                <Search className="w-8 h-8 text-zinc-300 mx-auto mb-2" />
                <p className="text-sm text-zinc-500">No properties match your search.</p>
              </div>
            )}

            {isAddingProperty && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="p-4 border-brand-primary/10 shadow-lg">
                  <form onSubmit={createProperty} className="space-y-4">
                    <h3 className="font-bold text-brand-dark">New Property Research</h3>
                    <div className="space-y-3">
                      <input 
                        required placeholder="Street Address" 
                        className="w-full px-3 py-2 rounded-lg border border-zinc-200 text-sm focus:ring-2 focus:ring-brand-primary/10 outline-none"
                        value={address} onChange={e => setAddress(e.target.value)}
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <input 
                          required placeholder="City" 
                          className="px-3 py-2 rounded-lg border border-zinc-200 text-sm focus:ring-2 focus:ring-brand-primary/10 outline-none"
                          value={city} onChange={e => setCity(e.target.value)}
                        />
                        <input 
                          required placeholder="State (e.g. CA)" 
                          className="px-3 py-2 rounded-lg border border-zinc-200 text-sm focus:ring-2 focus:ring-brand-primary/10 outline-none"
                          value={state} onChange={e => setState(e.target.value)}
                        />
                      </div>
                      <input 
                        required placeholder="Zip Code" 
                        className="w-full px-3 py-2 rounded-lg border border-zinc-200 text-sm focus:ring-2 focus:ring-brand-primary/10 outline-none"
                        value={zip} onChange={e => setZip(e.target.value)}
                      />
                      <select 
                        className="w-full px-3 py-2 rounded-lg border border-zinc-200 text-sm focus:ring-2 focus:ring-brand-primary/10 outline-none"
                        value={propType} onChange={e => setPropType(e.target.value)}
                      >
                        <option>Single Family</option>
                        <option>Condo</option>
                        <option>Townhouse</option>
                        <option>Apartment</option>
                      </select>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <Button type="submit" disabled={aiLoading} className="flex-1">
                        {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Start Research'}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsAddingProperty(false)}>Cancel</Button>
                    </div>
                    {aiLoading && (
                      <p className="text-[10px] text-zinc-400 text-center animate-pulse">
                        AI is researching local STR regulations...
                      </p>
                    )}
                  </form>
                </Card>
              </motion.div>
            )}

            {filteredProperties.map(prop => (
              <div 
                key={prop.id}
                onClick={() => setSelectedProperty(prop)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setSelectedProperty(prop); }}
                className={cn(
                  "w-full text-left p-4 rounded-2xl border transition-all group cursor-pointer",
                  selectedProperty?.id === prop.id 
                    ? "bg-white border-brand-primary shadow-md" 
                    : "bg-white border-zinc-100 hover:border-zinc-300 shadow-sm"
                )}
              >
                <div className="flex justify-between items-start mb-2">
                  <Badge variant={prop.status === 'Ready' ? 'success' : 'info'}>{prop.status}</Badge>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={(e) => { e.stopPropagation(); deleteProperty(prop.id); }}
                      className="p-1 hover:bg-red-50 text-zinc-400 hover:text-red-500 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <p className="font-bold text-brand-dark truncate">{prop.address}</p>
                <p className="text-xs text-zinc-500">{prop.city}, {prop.state}</p>
                
                <div className="mt-4 flex items-center justify-between text-[10px] font-medium text-zinc-400 uppercase tracking-wider">
                  <span>Compliance Progress</span>
                  <span>{Math.round((prop.checklist.filter(i => i.completed).length / prop.checklist.length) * 100)}%</span>
                </div>
                <div className="mt-1.5 h-1 w-full bg-zinc-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-brand-primary transition-all duration-500" 
                    style={{ width: `${(prop.checklist.filter(i => i.completed).length / prop.checklist.length) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="lg:col-span-8">
          <AnimatePresence mode="wait">
            {!selectedProperty ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="h-full flex flex-col items-center justify-center text-center p-12 bg-white border border-zinc-100 rounded-3xl"
              >
                <div className="w-20 h-20 bg-zinc-50 rounded-full flex items-center justify-center mb-6">
                  <Home className="w-10 h-10 text-zinc-200" />
                </div>
                <h3 className="text-2xl font-bold text-zinc-900 mb-2">Select a Property</h3>
                <p className="text-zinc-500 max-w-sm">
                  Choose a property from the list or add a new one to start your compliance journey.
                </p>
              </motion.div>
            ) : (
              <motion.div 
                key={selectedProperty.id}
                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                {/* Property Detail Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h2 className="text-3xl font-bold text-zinc-900">{selectedProperty.address}</h2>
                    </div>
                    <p className="text-zinc-500">{selectedProperty.city}, {selectedProperty.state} {selectedProperty.zipCode} • {selectedProperty.propertyType}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" className="text-xs" onClick={() => runResearch(selectedProperty)}>
                      <Search className="w-3.5 h-3.5" /> Re-Research
                    </Button>
                    <Button variant="outline" className="text-xs" onClick={() => setIsLawsModalOpen(true)}>
                      <Info className="w-3.5 h-3.5" /> View Local Laws
                    </Button>
                  </div>
                </div>

                {/* Local Laws Modal */}
                <AnimatePresence>
                  {isLawsModalOpen && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-900/50 backdrop-blur-sm">
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col"
                      >
                        <div className="p-6 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
                          <div>
                            <h3 className="text-xl font-bold text-zinc-900 flex items-center gap-2">
                              <Info className="w-5 h-5 text-brand-primary" />
                              Local Jurisdictional Rules
                            </h3>
                            <p className="text-sm text-zinc-500 mt-1">
                              {selectedProperty.city}, {selectedProperty.state}
                            </p>
                          </div>
                          <button 
                            onClick={() => setIsLawsModalOpen(false)}
                            className="p-2 hover:bg-zinc-200 rounded-full transition-colors text-zinc-500"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                        <div className="p-6 overflow-y-auto">
                          {selectedProperty.jurisdictionalRules ? (
                            <div className="prose prose-zinc max-w-none prose-sm">
                              <ReactMarkdown>{selectedProperty.jurisdictionalRules}</ReactMarkdown>
                            </div>
                          ) : (
                            <div className="text-center py-12">
                              <Info className="w-12 h-12 text-zinc-300 mx-auto mb-3" />
                              <p className="text-zinc-500 font-medium">No rules have been researched yet.</p>
                              <p className="text-sm text-zinc-400 mt-1">Click "Re-Research" to fetch local laws.</p>
                            </div>
                          )}
                        </div>
                        <div className="p-4 border-t border-zinc-100 bg-zinc-50 flex justify-end">
                          <Button variant="secondary" onClick={() => setIsLawsModalOpen(false)}>
                            Close
                          </Button>
                        </div>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>

                {/* HOA Upload Modal */}
                <AnimatePresence>
                  {hoaUploadItemId && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-900/50 backdrop-blur-sm">
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col"
                      >
                        <div className="p-6 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
                          <div>
                            <h3 className="text-xl font-bold text-zinc-900 flex items-center gap-2">
                              <Upload className="w-5 h-5 text-brand-primary" />
                              Upload HOA Document
                            </h3>
                            <p className="text-sm text-zinc-500 mt-1">
                              We couldn't automatically verify your HOA rules.
                            </p>
                          </div>
                          <button 
                            onClick={() => setHoaUploadItemId(null)}
                            className="p-2 hover:bg-zinc-200 rounded-full transition-colors text-zinc-500"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                        <div className="p-6 space-y-4">
                          <p className="text-sm text-zinc-600">
                            Please upload your HOA CC&Rs or bylaws so we can analyze them for short-term rental compliance.
                          </p>
                          <div className="grid grid-cols-1 gap-3">
                            <label className="flex items-center justify-center gap-2 p-4 border-2 border-dashed border-zinc-200 rounded-xl hover:border-brand-primary hover:bg-brand-primary/5 cursor-pointer transition-colors">
                              <Upload className="w-5 h-5 text-zinc-500" />
                              <span className="text-sm font-medium text-zinc-700">Upload from Computer</span>
                              <input 
                                type="file" 
                                className="hidden" 
                                accept="application/pdf,image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    analyzeDocument(file, 'HOA Agreement', hoaUploadItemId);
                                    setHoaUploadItemId(null);
                                  }
                                }}
                              />
                            </label>
                            <button 
                              onClick={() => {
                                alert('Google Drive integration requires OAuth setup. Please upload the file manually for now.');
                              }}
                              className="flex items-center justify-center gap-2 p-4 border border-zinc-200 rounded-xl hover:bg-zinc-50 transition-colors"
                            >
                              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15.3 4.5L8.7 15.9H2.1L8.7 4.5H15.3Z" fill="#0066DA"/>
                                <path d="M21.9 15.9L18.6 21.6H5.4L8.7 15.9H21.9Z" fill="#00AC47"/>
                                <path d="M21.9 15.9L15.3 4.5L12 10.2L18.6 21.6L21.9 15.9Z" fill="#EA4335"/>
                                <path d="M15.3 4.5L8.7 15.9H2.1L8.7 4.5H15.3Z" fill="#2684FC"/>
                                <path d="M21.9 15.9L18.6 21.6H5.4L8.7 15.9H21.9Z" fill="#00AA4A"/>
                                <path d="M21.9 15.9L15.3 4.5L12 10.2L18.6 21.6L21.9 15.9Z" fill="#FFBA00"/>
                              </svg>
                              <span className="text-sm font-medium text-zinc-700">Pull from Google Drive</span>
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Checklist Section */}
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                        Compliance Checklist
                      </h3>
                    </div>
                    <Card className="divide-y divide-zinc-50">
                      {selectedProperty.checklist.map(item => (
                        <div 
                          key={item.id} 
                          className={cn(
                            "p-4 flex items-start gap-3 transition-colors",
                            item.completed ? "bg-zinc-50/50" : "hover:bg-zinc-50/30"
                          )}
                        >
                          <button 
                            onClick={() => toggleChecklistItem(selectedProperty, item.id)}
                            className={cn(
                              "mt-0.5 w-5 h-5 rounded border flex items-center justify-center transition-all",
                              item.completed ? "bg-brand-primary border-brand-primary text-white" : "border-zinc-300 hover:border-zinc-400"
                            )}
                          >
                            {item.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                          </button>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-0.5">
                              <span className={cn("text-sm font-medium", item.completed ? "text-zinc-400 line-through" : "text-brand-dark")}>
                                {item.task}
                              </span>
                              <Badge variant="neutral">{item.category}</Badge>
                            </div>
                            {item.notes && <p className="text-xs text-zinc-400">{item.notes}</p>}
                          </div>
                        </div>
                      ))}
                    </Card>
                  </div>

                  {/* Documents Section */}
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
                        <FileText className="w-5 h-5 text-blue-500" />
                        Document Review
                      </h3>
                      <div className="flex gap-2">
                        <select 
                          className="text-xs px-2 py-1 rounded border border-zinc-200 bg-white"
                          id="docTypeSelect"
                        >
                          <option value="HOA Agreement">HOA Agreement</option>
                          <option value="Insurance">Insurance</option>
                          <option value="Permit Application">Permit Application</option>
                          <option value="Other">Other Document</option>
                        </select>
                        <label className="cursor-pointer">
                          <input 
                            type="file" 
                            className="hidden" 
                            accept="image/*,application/pdf"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              const typeSelect = document.getElementById('docTypeSelect') as HTMLSelectElement;
                              if (file) analyzeDocument(file, typeSelect.value as any);
                            }}
                          />
                          <div className="px-3 py-1.5 bg-zinc-100 text-zinc-900 rounded-lg text-sm font-medium hover:bg-zinc-200 transition-colors flex items-center gap-2">
                            <Upload className="w-4 h-4" /> Upload
                          </div>
                        </label>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {documents.length === 0 && (
                        <div className="text-center py-12 bg-white border border-zinc-100 rounded-2xl">
                          <Upload className="w-8 h-8 text-zinc-200 mx-auto mb-2" />
                          <p className="text-xs text-zinc-400">Upload HOA rules or insurance for AI review.</p>
                        </div>
                      )}
                      {documents
                        .sort((a, b) => {
                          const dateA = a.createdAt?.toMillis ? a.createdAt.toMillis() : 0;
                          const dateB = b.createdAt?.toMillis ? b.createdAt.toMillis() : 0;
                          return dateB - dateA;
                        })
                        .map(doc => (
                        <Card key={doc.id} className="p-4 space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                                <FileText className="w-5 h-5 text-blue-500" />
                              </div>
                              <div>
                                <p className="text-sm font-bold text-zinc-900">{doc.fileName}</p>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <p className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold">{doc.type}</p>
                                  <span className="text-[10px] text-zinc-300">•</span>
                                  <p className="text-[10px] text-zinc-400">
                                    {doc.createdAt?.toDate ? doc.createdAt.toDate().toLocaleDateString() : 'Just now'}
                                  </p>
                                </div>
                              </div>
                            </div>
                            <Badge variant={
                              doc.complianceStatus === 'Compliant' ? 'success' : 
                              doc.complianceStatus === 'Non-Compliant' ? 'error' : 'warning'
                            }>
                              {doc.complianceStatus}
                            </Badge>
                          </div>
                          {doc.analysis && (
                            <div className="text-xs text-zinc-600 bg-zinc-50 p-3 rounded-xl border border-zinc-100">
                              <p className="font-bold text-zinc-900 mb-1 flex items-center gap-1">
                                <ShieldCheck className="w-3 h-3" /> AI Analysis
                              </p>
                              <div className="prose prose-xs prose-zinc max-w-none">
                                <ReactMarkdown>
                                  {doc.analysis}
                                </ReactMarkdown>
                              </div>
                            </div>
                          )}
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Jurisdictional Rules Section */}
                {selectedProperty.jurisdictionalRules && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-zinc-900 flex items-center gap-2">
                      <Search className="w-5 h-5 text-zinc-400" />
                      AI Jurisdictional Research
                    </h3>
                    <Card className="p-6 bg-zinc-900 text-zinc-300">
                      <div className="prose prose-invert prose-sm max-w-none">
                        <ReactMarkdown>{selectedProperty.jurisdictionalRules}</ReactMarkdown>
                      </div>
                    </Card>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* AI Loading Overlay */}
      <AnimatePresence>
        {aiLoading && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center gap-4"
          >
            <div className="relative">
              <div className="w-16 h-16 border-4 border-zinc-100 border-t-brand-primary rounded-full animate-spin" />
              <ShieldCheck className="w-6 h-6 text-brand-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-brand-dark">AI is working...</p>
              <p className="text-sm text-zinc-500">Researching regulations and analyzing documents.</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error Toast */}
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 bg-red-600 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 z-50"
          >
            <AlertCircle className="w-5 h-5" />
            <span className="font-medium">{error}</span>
            <button onClick={() => setError(null)} className="ml-2 hover:opacity-70">×</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
    </ErrorBoundary>
  );
}
